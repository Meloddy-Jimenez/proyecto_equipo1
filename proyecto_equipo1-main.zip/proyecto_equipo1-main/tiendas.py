import csv  # Librería para abrir, leer y escribir archivos CSV


class Tiendas:  # Clase Tiendas

    def __init__(self):  # Construcctor de la clase Tiendas
        pass  # Inicializa el objeto Tiendas

    def listarTiendas(self) -> bool:  # Metodo para listar las tiendas
        # TODO programar el método listarTiendas()
        return False  # Regresa False si ocurrio un error en el metodo

    def insertarTienda(self) -> bool:  # Metodo para insertar una tienda
        # TODO programar el método insertarTienda()
        return False  # Regresa False si ocurrio un error en el metodo

    def buscarTienda(self, nombre: str) -> bool:  # Metodo para buscar tiendas por nombre
        # TODO programar el método buscarTienda()
        return False  # Regresa False si ocurrio un error en el metodo

    def borrarTienda(self, id: int) -> bool:  # Metodo para borrar tiendas por id
        # TODO programar el método borrarTienda()
        return False  # Regresa False si ocurrio un error en el metodo

    def actualizarTienda(self) -> bool:  # Metodo para actualizar los datos de un tienda
        # TODO programar el método actualizarTienda()
        return False  # Regresa False si ocurrio un error en el metodo
